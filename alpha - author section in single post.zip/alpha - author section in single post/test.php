css dynamic
js dynamic
logo dynamic
header backgound dynamic
text color dynamic 
===================
title and tagline dynamic
site url dynamic
====================
post-title, author, date, tag-list dynamic
featured image/thumbnail image and content or excerpt dynamic
====================
sidebar and footer dynamic
top menu and footer menu dynamic

<?php
	function alpha_assets(){
		//css dynamic
		wp_enqueue_style("bootstrap", get_theme_file_uri("/assets/css/bootstrap.min.css"));
		wp_enqueue_style("animate", get_theme_file_uri("/assets/css/animate.css"));
		wp_enqueue_style("fontawesome", get_theme_file_uri("/assets/css/fontawesome.min.css"));
		wp_enqueue_style("style", get_stylesheet_uri());
		
		wp_enqueue_script("bootstrap-jquery-js",get_theme_file_uri("/assets/css/fontawesome.min.js"),array(""),"1.0",true);
	}
	add_acton("wp_enqueue_scripts","alpha_assets");
?>

<?php the_title(); ?>
<?php the_author(); ?>
<?php echo get_the_date(); ?>
<?php echo get_the_tag_list(); ?>

<?php
	if(has_post_thumbnail){
		the_post_thumbnail("large", array("class"=>"img-fluid") );
	}
	the_content();
?>