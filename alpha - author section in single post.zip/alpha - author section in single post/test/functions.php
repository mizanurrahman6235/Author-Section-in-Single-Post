<?php

if(site_url()=="http://localhost/naser"){
	define("VERSION",time());
}else{
	define("VERSION", wp_get_theme()->get("Version"));
}

function alpha_bootstrapping(){
    load_theme_textdomain("alpha");
    add_theme_support("post-thumbnails");
    add_theme_support("title-tag");
	$alpha_custom_header_details = array(
		'header_text'			=> true,
		'default_text_color'	=> '#f00'
	);
    add_theme_support("custom-header", $alpha_custom_header_details);
	
	$alpha_custom_logo_defaults = array(
		'width' => '100',
		'height' => '100'
	);
	add_theme_support("custom-logo", $alpha_custom_logo_defaults);
	add_theme_support("header_text");
	register_nav_menu("topmenu",__("Top Menu","alpha"));
	register_nav_menu("footermenu",__("Footer Menu","alpha"));
	
	add_theme_support("post-formats", array("image","audio","gallery","video","quote","link"));
}
add_action("after_setup_theme","alpha_bootstrapping");

function alpha_assets(){
   
    wp_enqueue_style("bootstrap","//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css");
    wp_enqueue_style("featherlight-css","//cdn.jsdelivr.net/npm/featherlight@1.7.14/release/featherlight.min.css");   
	wp_enqueue_style("dashicons");
	wp_enqueue_style("alpha", get_stylesheet_uri(), null, VERSION );
    wp_enqueue_script("featherlight-js","//cdn.jsdelivr.net/npm/featherlight@1.7.14/release/featherlight.min.js", array("jquery"),"1.7.0", true);
	
}
add_action("wp_enqueue_scripts","alpha_assets");

function alpha_sidebar() {
    register_sidebar( array(
        'name'          => __( 'Single Post Sidebar', 'alpha' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'Right sidebar', 'alpha' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
    register_sidebar( array(
        'name'          => __( 'Footer left', 'alpha' ),
        'id'            => 'footer-left',
        'description'   => __( 'Footer Left', 'alpha' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => ' ',
        'after_title'   => ' ',
    ) );
    register_sidebar( array(
        'name'          => __( 'Footer Right', 'alpha' ),
        'id'            => 'footer-right',
        'description'   => __( 'Footer Right', 'alpha' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => ' ',
        'after_title'   => ' ',
    ) );
}
add_action( 'widgets_init', 'alpha_sidebar' );

/*
// password protected form
function alpha_the_excerpt($excerpt){
	if(!post_password_required()){
		return $excerpt;
	}else{
		echo get_the_password_form();
	}
}
add_filter("the_excerpt","alpha_the_excerpt");

*/

// password protected form and change title
function alpha_protected_title_change(){
	return "%s";
}
add_filter("protected_title_format","alpha_protected_title_change");


// nav menu css class
function alpha_menu_css_class( $classes , $item ){
	$classes[] = "list-inline-item";
	return $classes;
}
add_filter("nav_menu_css_class","alpha_menu_css_class", 10, 2);

//---------- custom header & featured image header----------
function alpha_about_page_template_banner(){
	if(is_post){
		$alpha_feat_image = get_the_post_thumbnail_url(null, "large");
		?>
		<style>
			.page-header{
				background-image: url(<?php echo $alpha_feat_image; ?>);
			}
		</style>
		<?php
	}
	if(is_front_page()){ // custom header
		if(current_theme_supports("custom-header")){
			?>
			<style>
				.header{
					background-image: url(<?php echo header_image(); ?>);
					margin-bottom: 50px;
					background-repeat: no-repeat;
				}
				.header h1.heading a, h3.tagline{
					color: #<?php echo get_header_textcolor(); ?>;
					text-decoration: none;
					<?php
						if(!display_header_text()){
							echo "display: none;";
						}
					?>
				}
			</style>
			<?php
		}
	}
}
add_action("wp_head","alpha_about_page_template_banner",11);

?>